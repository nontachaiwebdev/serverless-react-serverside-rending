# serverless-react-serverside-rending
this repo is lab to create a simple serverside render with react and serverless
